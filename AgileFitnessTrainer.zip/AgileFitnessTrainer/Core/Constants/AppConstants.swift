// AppConstants.swift

import Foundation

enum AppConstants {
    // TODO: Replace with your actual Gemini API key
    static let geminiAPIKey: String = {
        guard let key = Bundle.main.infoDictionary?["GEMINI_API_KEY"] as? String, !key.isEmpty else {
            return "YOUR_GEMINI_API_KEY_HERE"
        }
        return key
    }()

    static let fallbackSystemPrompt = "Jsi fitness trenér Jakub. Odpovídej vždy validním JSON."

    static let progressiveOverloadUpperBodyIncrement: Double = 2.5
    static let progressiveOverloadLowerBodyIncrement: Double = 5.0
    static let progressiveOverloadDeloadPercent: Double = 0.95
    static let progressiveOverloadLookbackSessions: Int = 3
}

enum AppError: Error, LocalizedError {
    case noPlanForToday
    case encodingFailed
    case healthKitUnavailable
    case noActiveProfile

    var errorDescription: String? {
        switch self {
        case .noPlanForToday:       return "Pro dnešní den není naplánován trénink."
        case .encodingFailed:       return "Chyba při přípravě dat pro AI."
        case .healthKitUnavailable: return "HealthKit není dostupný na tomto zařízení."
        case .noActiveProfile:      return "Nenalezen aktivní uživatelský profil."
        }
    }
}
