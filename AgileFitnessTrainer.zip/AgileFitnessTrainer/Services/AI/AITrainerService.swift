// AITrainerService.swift

import Foundation
import SwiftData

@MainActor
final class AITrainerService: ObservableObject {

    private let apiClient:      GeminiAPIClient
    private let contextBuilder: TrainerContextBuilder
    private let systemPrompt:   String

    @Published var isLoading = false
    @Published var error: AppError?

    init(modelContext: ModelContext, healthKitService: HealthKitService) {
        self.apiClient      = GeminiAPIClient(apiKey: AppConstants.geminiAPIKey)
        self.contextBuilder = TrainerContextBuilder(
            modelContext: modelContext,
            healthKitService: healthKitService
        )
        self.systemPrompt = SystemPromptLoader.load()
    }

    // MARK: - Public API

    func generateTodayWorkout(
        for date: Date = .now,
        profile: UserProfile
    ) async throws -> TrainerResponse {
        isLoading = true
        defer { isLoading = false }

        let context     = try await contextBuilder.buildContext(for: date, profile: profile)
        let userMessage = try buildUserMessage(context: context)
        let rawJSON     = try await apiClient.generate(
            systemPrompt: systemPrompt,
            userMessage:  userMessage
        )
        let response = try parseResponse(rawJSON: rawJSON)
        await persistAIMetadata(response: response, date: date, profile: profile)
        return response
    }

    // MARK: - Private

    private func buildUserMessage(context: TrainerRequestContext) throws -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting     = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(context)
        guard let json = String(data: data, encoding: .utf8) else {
            throw AppError.encodingFailed
        }
        return """
        Toto jsou moje dnešní data. Vygeneruj mi optimální trénink.
        Odpověz POUZE validním JSON objektem přesně dle schématu ze system promptu.

        \(json)
        """
    }

    private func parseResponse(rawJSON: String) throws -> TrainerResponse {
        let cleaned = rawJSON
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```",     with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard let data = cleaned.data(using: .utf8) else {
            throw GeminiError.jsonParsingFailed("Nelze převést na Data")
        }
        do {
            return try JSONDecoder().decode(TrainerResponse.self, from: data)
        } catch {
            throw GeminiError.jsonParsingFailed(error.localizedDescription)
        }
    }

    @discardableResult
    private func persistAIMetadata(
        response: TrainerResponse,
        date: Date,
        profile: UserProfile
    ) async -> Bool {
        guard
            let plan    = profile.workoutPlans.first(where: \.isActive),
            let session = plan.sessions.first(where: { $0.startedAt.isSameDay(as: date) })
        else { return false }

        session.aiAdaptationNote = response.adaptationReason
        session.readinessScore   = switch response.readinessLevel {
        case "green":  85.0
        case "orange": 55.0
        default:       25.0
        }
        return true
    }
}

// MARK: - SystemPromptLoader

enum SystemPromptLoader {
    static func load() -> String {
        guard
            let url  = Bundle.main.url(forResource: "SystemPrompt", withExtension: "txt"),
            let text = try? String(contentsOf: url, encoding: .utf8)
        else {
            assertionFailure("SystemPrompt.txt nenalezen v bundle!")
            return AppConstants.fallbackSystemPrompt
        }
        return text
    }
}
