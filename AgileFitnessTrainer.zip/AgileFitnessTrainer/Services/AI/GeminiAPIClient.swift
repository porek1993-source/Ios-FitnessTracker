// GeminiAPIClient.swift

import Foundation

actor GeminiAPIClient {

    private let apiKey: String
    private let model   = "gemini-2.5-flash-lite-preview-06-17"
    private let session: URLSession

    private var endpoint: URL {
        URL(string:
            "https://generativelanguage.googleapis.com/v1beta/models/"
            + "\(model):generateContent?key=\(apiKey)"
        )!
    }

    init(apiKey: String) {
        self.apiKey  = apiKey
        self.session = URLSession(configuration: .default)
    }

    func generate(systemPrompt: String, userMessage: String) async throws -> String {
        let body = GeminiRequest(
            systemInstruction: .init(parts: [.init(text: systemPrompt)]),
            contents: [.init(role: "user", parts: [.init(text: userMessage)])],
            generationConfig: .init(
                temperature:      0.4,
                topP:             0.85,
                maxOutputTokens:  2048,
                responseMimeType: "application/json"
            )
        )

        var request        = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody   = try JSONEncoder().encode(body)
        request.timeoutInterval = 30

        let (data, response) = try await session.data(for: request)

        guard let http = response as? HTTPURLResponse else {
            throw GeminiError.invalidResponse
        }
        guard (200..<300).contains(http.statusCode) else {
            let body = String(data: data, encoding: .utf8) ?? "unknown"
            throw GeminiError.httpError(statusCode: http.statusCode, body: body)
        }

        let parsed = try JSONDecoder().decode(GeminiResponse.self, from: data)
        guard let text = parsed.candidates.first?.content.parts.first?.text else {
            throw GeminiError.emptyResponse
        }
        return text
    }
}

// MARK: - Wire Types

private struct GeminiRequest: Encodable {
    let systemInstruction: Content
    let contents: [Content]
    let generationConfig: GenerationConfig

    struct Content: Encodable {
        var role: String?
        let parts: [Part]
        struct Part: Encodable { let text: String }
    }
    struct GenerationConfig: Encodable {
        let temperature: Double
        let topP: Double
        let maxOutputTokens: Int
        let responseMimeType: String
    }
}

private struct GeminiResponse: Decodable {
    let candidates: [Candidate]
    struct Candidate: Decodable {
        let content: Content
        struct Content: Decodable {
            let parts: [Part]
            struct Part: Decodable { let text: String }
        }
    }
}

enum GeminiError: Error, LocalizedError {
    case invalidResponse
    case httpError(statusCode: Int, body: String)
    case emptyResponse
    case jsonParsingFailed(String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse:           return "Neplatná odpověď serveru."
        case .httpError(let s, let b):   return "HTTP \(s): \(b)"
        case .emptyResponse:             return "Gemini vrátilo prázdnou odpověď."
        case .jsonParsingFailed(let m):  return "JSON chyba: \(m)"
        }
    }
}
