// WorkoutView.swift

import SwiftUI

struct WorkoutView: View {
    @StateObject private var vm: WorkoutViewModel
    @Environment(\.dismiss) private var dismiss

    init(session: WorkoutSession, plan: PlannedWorkoutDay, planLabel: String) {
        _vm = StateObject(wrappedValue: WorkoutViewModel(session: session, plan: plan, planLabel: planLabel))
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                WorkoutHeaderView(vm: vm)

                TabView(selection: $vm.currentExerciseIndex) {
                    ForEach(vm.exercises.indices, id: \.self) { index in
                        ExerciseCardView(exercise: vm.exercises[index], vm: vm)
                            .tag(index)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                .animation(.easeInOut, value: vm.currentExerciseIndex)
            }

            if vm.isResting {
                RestTimerOverlay(vm: vm)
                    .transition(.asymmetric(
                        insertion: .scale(scale: 0.8).combined(with: .opacity),
                        removal:   .opacity
                    ))
            }
        }
        .preferredColorScheme(.dark)
        .navigationBarHidden(true)
    }
}

// MARK: - Header

struct WorkoutHeaderView: View {
    @ObservedObject var vm: WorkoutViewModel

    var body: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 2) {
                Text("ČAS")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.4))
                    .kerning(1.5)
                Text(vm.elapsedTimeFormatted)
                    .font(.system(size: 20, weight: .bold, design: .monospaced))
                    .foregroundStyle(.white)
            }

            Spacer()

            HStack(spacing: 6) {
                ForEach(vm.exercises.indices, id: \.self) { i in
                    Circle()
                        .fill(progressDotColor(index: i))
                        .frame(
                            width:  i == vm.currentExerciseIndex ? 8 : 5,
                            height: i == vm.currentExerciseIndex ? 8 : 5
                        )
                        .animation(.spring(response: 0.3), value: vm.currentExerciseIndex)
                }
            }

            Spacer()

            Button { vm.finishWorkout() } label: {
                Text("Dokončit")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 7)
                    .background(Capsule().fill(Color.white.opacity(0.15)))
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 16)
    }

    private func progressDotColor(index: Int) -> Color {
        if index < vm.currentExerciseIndex  { return .green }
        if index == vm.currentExerciseIndex { return .white }
        return .white.opacity(0.25)
    }
}

// MARK: - Exercise Card

struct ExerciseCardView: View {
    let exercise: SessionExerciseState
    @ObservedObject var vm: WorkoutViewModel

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                ExerciseAnimationView(slug: exercise.slug)
                    .frame(height: 260)

                VStack(spacing: 24) {
                    VStack(spacing: 8) {
                        Text(exercise.name)
                            .font(.system(size: 26, weight: .bold))
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)

                        if let tip = exercise.coachTip {
                            HStack(alignment: .top, spacing: 8) {
                                Image(systemName: "lightbulb.fill")
                                    .foregroundStyle(.yellow)
                                    .font(.system(size: 13))
                                    .padding(.top, 1)
                                Text(tip)
                                    .font(.system(size: 14))
                                    .foregroundStyle(.white.opacity(0.7))
                                    .multilineTextAlignment(.leading)
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color.yellow.opacity(0.08))
                                    .overlay(RoundedRectangle(cornerRadius: 12)
                                        .strokeBorder(Color.yellow.opacity(0.2), lineWidth: 1))
                            )
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)

                    TechTipsRow(exercise: exercise)
                        .padding(.horizontal, 20)

                    VStack(spacing: 10) {
                        SetHeaderRow()
                        ForEach(exercise.sets.indices, id: \.self) { i in
                            SetRowView(
                                setNumber: i + 1,
                                setData:   $vm.exercises[vm.currentExerciseIndex].sets[i],
                                isActive:  i == exercise.nextIncompleteSetIndex,
                                onComplete: {
                                    vm.completeSet(
                                        exerciseIndex: vm.currentExerciseIndex,
                                        setIndex: i
                                    )
                                }
                            )
                        }
                    }
                    .padding(.horizontal, 20)

                    Button { vm.skipExercise() } label: {
                        Label("Přeskočit cvik", systemImage: "forward.fill")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(.white.opacity(0.4))
                    }
                    .padding(.bottom, 40)
                }
            }
        }
    }
}

// MARK: - Tech Tips

struct TechTipsRow: View {
    let exercise: SessionExerciseState
    var body: some View {
        HStack(spacing: 10) {
            if let tempo = exercise.tempo {
                TechBadge(icon: "metronome.fill", label: "Tempo", value: tempo, color: .blue)
            }
            TechBadge(icon: "wind", label: "Dýchání", value: "Výdech při zdvihu", color: .teal)
            if exercise.restSeconds > 0 {
                TechBadge(icon: "timer", label: "Pauza", value: "\(exercise.restSeconds)s", color: .orange)
            }
        }
    }
}

struct TechBadge: View {
    let icon: String
    let label: String
    let value: String
    let color: Color

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: icon).foregroundStyle(color).font(.system(size: 12))
            VStack(alignment: .leading, spacing: 1) {
                Text(label.uppercased())
                    .font(.system(size: 8, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.4))
                    .kerning(0.8)
                Text(value)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.white)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(RoundedRectangle(cornerRadius: 10).fill(color.opacity(0.1)))
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Set Header

struct SetHeaderRow: View {
    var body: some View {
        HStack {
            Text("SET").frame(width: 36, alignment: .leading)
            Text("KG").frame(maxWidth: .infinity)
            Text("REPS").frame(maxWidth: .infinity)
            Text("RPE").frame(width: 52)
            Spacer().frame(width: 44)
        }
        .font(.system(size: 10, weight: .semibold))
        .foregroundStyle(.white.opacity(0.35))
        .kerning(1.2)
        .padding(.horizontal, 4)
    }
}

// MARK: - Set Row

struct SetRowView: View {
    let setNumber: Int
    @Binding var setData: SetState
    let isActive: Bool
    let onComplete: () -> Void

    @FocusState private var weightFocused: Bool
    @FocusState private var repsFocused: Bool

    var body: some View {
        HStack(spacing: 8) {
            ZStack {
                Circle()
                    .fill(setData.isCompleted
                          ? Color.green.opacity(0.25)
                          : (isActive ? Color.white.opacity(0.12) : Color.white.opacity(0.05)))
                    .frame(width: 32, height: 32)
                if setData.isCompleted {
                    Image(systemName: "checkmark")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(.green)
                } else {
                    Text("\(setNumber)")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(isActive ? .white : .white.opacity(0.4))
                }
            }
            .frame(width: 36)

            CompactNumberField(
                value: Binding(
                    get: { setData.weightKg },
                    set: { setData.weightKg = $0 }
                ),
                placeholder: setData.previousWeightKg.map { String(format: "%.1f", $0) } ?? "—",
                isFocused: _weightFocused,
                isActive: isActive,
                isCompleted: setData.isCompleted
            )
            .frame(maxWidth: .infinity)

            CompactIntField(
                value: Binding(
                    get: { setData.reps },
                    set: { setData.reps = $0 }
                ),
                placeholder: "\(setData.targetRepsMin)–\(setData.targetRepsMax)",
                isFocused: _repsFocused,
                isActive: isActive,
                isCompleted: setData.isCompleted
            )
            .frame(maxWidth: .infinity)

            RPEPicker(
                value: Binding(
                    get: { setData.rpe },
                    set: { setData.rpe = $0 }
                ),
                isActive: isActive,
                isCompleted: setData.isCompleted
            )
            .frame(width: 52)

            Button { onComplete() } label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(isActive ? (canComplete ? Color.green : Color.white.opacity(0.08)) : Color.clear)
                        .frame(width: 44, height: 40)
                    Image(systemName: setData.isCompleted ? "checkmark.circle.fill" : "checkmark")
                        .font(.system(size: setData.isCompleted ? 20 : 16, weight: .semibold))
                        .foregroundStyle(setData.isCompleted ? .green : (canComplete ? .white : .white.opacity(0.2)))
                }
            }
            .disabled(!isActive && !setData.isCompleted)
            .animation(.spring(response: 0.25), value: setData.isCompleted)
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 2)
        .opacity(setData.isCompleted ? 0.6 : (isActive ? 1.0 : 0.45))
        .animation(.easeInOut(duration: 0.2), value: isActive)
    }

    private var canComplete: Bool { setData.weightKg != nil && setData.reps != nil }
}

// MARK: - Number Fields

struct CompactNumberField: View {
    @Binding var value: Double?
    let placeholder: String
    @FocusState var isFocused: Bool
    let isActive: Bool
    let isCompleted: Bool
    @State private var text = ""

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(isFocused ? Color.white.opacity(0.12) : (isActive ? Color.white.opacity(0.07) : Color.clear))
                .overlay(RoundedRectangle(cornerRadius: 10)
                    .strokeBorder(isFocused ? Color.blue.opacity(0.8) : Color.clear, lineWidth: 1.5))
            if text.isEmpty && !isFocused {
                Text(placeholder)
                    .font(.system(size: 16, weight: .semibold, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.25))
            }
            TextField("", text: $text)
                .keyboardType(.decimalPad)
                .focused($isFocused)
                .font(.system(size: 16, weight: .semibold, design: .monospaced))
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .onChange(of: text) { _, v in
                    value = Double(v.replacingOccurrences(of: ",", with: "."))
                }
        }
        .frame(height: 42)
        .disabled(!isActive || isCompleted)
    }
}

struct CompactIntField: View {
    @Binding var value: Int?
    let placeholder: String
    @FocusState var isFocused: Bool
    let isActive: Bool
    let isCompleted: Bool
    @State private var text = ""

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(isFocused ? Color.white.opacity(0.12) : (isActive ? Color.white.opacity(0.07) : Color.clear))
                .overlay(RoundedRectangle(cornerRadius: 10)
                    .strokeBorder(isFocused ? Color.blue.opacity(0.8) : Color.clear, lineWidth: 1.5))
            if text.isEmpty && !isFocused {
                Text(placeholder)
                    .font(.system(size: 16, weight: .semibold, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.25))
            }
            TextField("", text: $text)
                .keyboardType(.numberPad)
                .focused($isFocused)
                .font(.system(size: 16, weight: .semibold, design: .monospaced))
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .onChange(of: text) { _, v in value = Int(v) }
        }
        .frame(height: 42)
        .disabled(!isActive || isCompleted)
    }
}

// MARK: - RPE Picker

struct RPEPicker: View {
    @Binding var value: Int?
    let isActive: Bool
    let isCompleted: Bool
    @State private var showPicker = false

    var body: some View {
        Button { guard isActive && !isCompleted else { return }; showPicker = true } label: {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(isActive && !isCompleted ? Color.white.opacity(0.07) : Color.clear)
                VStack(spacing: 1) {
                    if let v = value {
                        Text("\(v)").font(.system(size: 17, weight: .bold, design: .monospaced)).foregroundStyle(rpeColor(v))
                        Text("RPE").font(.system(size: 8, weight: .semibold)).foregroundStyle(.white.opacity(0.35))
                    } else {
                        Text("—").font(.system(size: 17, weight: .semibold)).foregroundStyle(.white.opacity(0.25))
                        Text("RPE").font(.system(size: 8, weight: .semibold)).foregroundStyle(.white.opacity(0.2))
                    }
                }
            }
            .frame(width: 52, height: 42)
        }
        .sheet(isPresented: $showPicker) {
            RPEPickerSheet(value: $value).presentationDetents([.height(320)])
        }
    }

    private func rpeColor(_ v: Int) -> Color {
        switch v {
        case 1...5: return .green
        case 6...7: return .yellow
        case 8:     return .orange
        default:    return .red
        }
    }
}

struct RPEPickerSheet: View {
    @Binding var value: Int?
    @Environment(\.dismiss) private var dismiss
    private let labels = [
        1: "Velmi lehce", 2: "Lehce", 3: "Mírně", 4: "Trochu snaha", 5: "Střední",
        6: "Náročné", 7: "Těžké", 8: "Velmi těžké", 9: "Maximální", 10: "Absolutní max"
    ]

    var body: some View {
        VStack(spacing: 16) {
            Text("Jak těžká byla série?")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(.white)
                .padding(.top, 20)
            LazyVGrid(columns: Array(repeating: .init(.flexible(), spacing: 8), count: 5), spacing: 8) {
                ForEach(1...10, id: \.self) { i in
                    Button {
                        value = i
                        dismiss()
                    } label: {
                        VStack(spacing: 4) {
                            Text("\(i)").font(.system(size: 22, weight: .bold))
                            Text(labels[i] ?? "").font(.system(size: 9)).multilineTextAlignment(.center).lineLimit(2)
                        }
                        .foregroundStyle(value == i ? .black : .white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(RoundedRectangle(cornerRadius: 10)
                            .fill(value == i ? rpeColor(i) : Color.white.opacity(0.1)))
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
        .background(Color(white: 0.1).ignoresSafeArea())
    }

    private func rpeColor(_ v: Int) -> Color {
        switch v {
        case 1...5: return .green
        case 6...7: return .yellow
        case 8:     return .orange
        default:    return .red
        }
    }
}

// MARK: - Rest Timer Overlay

struct RestTimerOverlay: View {
    @ObservedObject var vm: WorkoutViewModel

    var body: some View {
        ZStack {
            Color.black.opacity(0.75).ignoresSafeArea().onTapGesture { vm.skipRest() }
            VStack(spacing: 24) {
                Text("PAUZA")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.5))
                    .kerning(2)
                ZStack {
                    Circle().stroke(Color.white.opacity(0.1), lineWidth: 8).frame(width: 160, height: 160)
                    Circle()
                        .trim(from: 0, to: vm.restProgress)
                        .stroke(
                            AngularGradient(colors: [.blue, .cyan], center: .center),
                            style: StrokeStyle(lineWidth: 8, lineCap: .round)
                        )
                        .frame(width: 160, height: 160)
                        .rotationEffect(.degrees(-90))
                        .animation(.linear(duration: 1), value: vm.restProgress)
                    VStack(spacing: 4) {
                        Text(vm.restTimeFormatted)
                            .font(.system(size: 52, weight: .bold, design: .monospaced))
                            .foregroundStyle(.white)
                            .contentTransition(.numericText(countsDown: true))
                        Text("zbývá").font(.system(size: 13)).foregroundStyle(.white.opacity(0.4))
                    }
                }
                HStack(spacing: 16) {
                    TimerAdjustButton(label: "−15s") { vm.adjustRest(by: -15) }
                    Button { vm.skipRest() } label: {
                        Text("Přeskočit")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(.black)
                            .frame(width: 140, height: 48)
                            .background(Capsule().fill(Color.white))
                    }
                    TimerAdjustButton(label: "+15s") { vm.adjustRest(by: 15) }
                }
                Text("Klepni kamkoliv pro přeskočení")
                    .font(.system(size: 12))
                    .foregroundStyle(.white.opacity(0.25))
            }
        }
    }
}

struct TimerAdjustButton: View {
    let label: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(label)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 60, height: 48)
                .background(Capsule().fill(Color.white.opacity(0.12)))
        }
    }
}

// MARK: - Exercise Animation

struct ExerciseAnimationView: View {
    let slug: String
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(white: 0.08), Color.black], startPoint: .top, endPoint: .bottom)
            VStack(spacing: 12) {
                Image(systemName: exerciseIcon(slug))
                    .font(.system(size: 64))
                    .foregroundStyle(LinearGradient(colors: [.blue, .cyan], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .symbolEffect(.pulse)
                Text("animace cviku")
                    .font(.system(size: 11))
                    .foregroundStyle(.white.opacity(0.2))
            }
            LinearGradient(colors: [.clear, .black], startPoint: .init(x: 0.5, y: 0.6), endPoint: .bottom)
        }
    }

    private func exerciseIcon(_ slug: String) -> String {
        if slug.contains("bench") || slug.contains("press") { return "dumbbell.fill" }
        if slug.contains("squat") || slug.contains("leg")   { return "figure.strengthtraining.traditional" }
        if slug.contains("pull") || slug.contains("row")    { return "figure.gymnastics" }
        if slug.contains("run")  || slug.contains("cardio") { return "figure.run" }
        return "figure.core.training"
    }
}

// MARK: - ViewModel

@MainActor
final class WorkoutViewModel: ObservableObject {
    @Published var exercises: [SessionExerciseState]
    @Published var currentExerciseIndex = 0
    @Published var isResting = false
    @Published var restSecondsRemaining = 0
    @Published var totalRestSeconds = 90
    @Published var elapsedSeconds = 0

    private var restTimer: Timer?
    private var elapsedTimer: Timer?
    let session: WorkoutSession
    let planLabel: String

    init(session: WorkoutSession, plan: PlannedWorkoutDay, planLabel: String) {
        self.session   = session
        self.planLabel = planLabel
        self.exercises = plan.plannedExercises
            .sorted { $0.order < $1.order }
            .map { SessionExerciseState(from: $0) }
        startElapsedTimer()
    }

    private func startElapsedTimer() {
        elapsedTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in self?.elapsedSeconds += 1 }
        }
    }

    func completeSet(exerciseIndex: Int, setIndex: Int) {
        guard
            exercises[exerciseIndex].sets[setIndex].weightKg != nil,
            exercises[exerciseIndex].sets[setIndex].reps     != nil
        else { return }

        withAnimation(.spring(response: 0.3)) {
            exercises[exerciseIndex].sets[setIndex].isCompleted = true
        }

        let exercise    = exercises[exerciseIndex]
        let restSeconds = exercise.restSeconds

        Task {
            await LiveActivityManager.shared.startRestActivity(
                session:          session,
                currentExercise:  exercise,
                completedSetIndex: setIndex,
                restSeconds:      restSeconds,
                planLabel:        planLabel
            )
        }

        startRestTimer(seconds: restSeconds)

        let allDone = exercises[exerciseIndex].sets.allSatisfy(\.isCompleted)
        if allDone {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(restSeconds) + 0.5) { [weak self] in
                self?.advanceToNextExercise()
            }
        }
    }

    private func startRestTimer(seconds: Int) {
        guard seconds > 0 else { return }
        restTimer?.invalidate()
        totalRestSeconds     = seconds
        restSecondsRemaining = seconds
        withAnimation { isResting = true }

        restTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self else { return }
                if self.restSecondsRemaining > 1 {
                    self.restSecondsRemaining -= 1
                } else {
                    self.skipRest()
                }
            }
        }
    }

    func skipRest() {
        restTimer?.invalidate()
        withAnimation(.spring(response: 0.35)) { isResting = false }
        Task { await LiveActivityManager.shared.endWithDismissalDelay(2) }
    }

    func adjustRest(by delta: Int) {
        restSecondsRemaining = max(0, restSecondsRemaining + delta)
        if restSecondsRemaining == 0 { skipRest(); return }
        let newEndsAt = Date.now.addingTimeInterval(Double(restSecondsRemaining))
        Task {
            await LiveActivityManager.shared.updateRestTimer(
                newEndsAt: newEndsAt,
                totalSeconds: restSecondsRemaining
            )
        }
    }

    func skipExercise() { withAnimation { advanceToNextExercise() } }

    private func advanceToNextExercise() {
        guard currentExerciseIndex < exercises.count - 1 else { return }
        withAnimation(.easeInOut) { currentExerciseIndex += 1 }
    }

    func finishWorkout() {
        restTimer?.invalidate()
        elapsedTimer?.invalidate()
        Task { await LiveActivityManager.shared.endCurrentActivity() }
    }

    var restProgress: Double {
        guard totalRestSeconds > 0 else { return 0 }
        return Double(restSecondsRemaining) / Double(totalRestSeconds)
    }

    var restTimeFormatted: String {
        let m = restSecondsRemaining / 60
        let s = restSecondsRemaining % 60
        return m > 0 ? "\(m):\(String(format: "%02d", s))" : "\(s)"
    }

    var elapsedTimeFormatted: String {
        let h = elapsedSeconds / 3600
        let m = (elapsedSeconds % 3600) / 60
        let s = elapsedSeconds % 60
        return h > 0
            ? String(format: "%d:%02d:%02d", h, m, s)
            : String(format: "%d:%02d", m, s)
    }
}

// MARK: - State Models

struct SessionExerciseState: Identifiable {
    let id: UUID
    let name: String
    let slug: String
    let coachTip: String?
    let tempo: String?
    let restSeconds: Int
    var sets: [SetState]

    var nextIncompleteSetIndex: Int? {
        sets.indices.first { !sets[$0].isCompleted }
    }

    init(from planned: PlannedExercise) {
        self.id          = UUID()
        self.name        = planned.exercise?.name ?? ""
        self.slug        = planned.exercise?.slug ?? ""
        self.coachTip    = nil
        self.tempo       = nil
        self.restSeconds = planned.restSeconds
        self.sets = (0..<planned.targetSets).map { _ in
            SetState(
                targetRepsMin:    planned.targetRepsMin,
                targetRepsMax:    planned.targetRepsMax,
                previousWeightKg: planned.exercise?.lastUsedWeight
            )
        }
    }

    init(from response: ResponseExercise) {
        self.id          = UUID()
        self.name        = response.name
        self.slug        = response.slug
        self.coachTip    = response.coachTip
        self.tempo       = response.tempo
        self.restSeconds = response.restSeconds
        self.sets = (0..<response.sets).map { _ in
            SetState(
                targetRepsMin:    response.repsMin,
                targetRepsMax:    response.repsMax,
                previousWeightKg: response.weightKg
            )
        }
    }
}

struct SetState {
    var weightKg: Double?
    var reps: Int?
    var rpe: Int?
    var isCompleted = false
    let targetRepsMin: Int
    let targetRepsMax: Int
    let previousWeightKg: Double?
}
