// AgileFitnessTrainerApp.swift
// Agilní Fitness Trenér — @main entry point

import SwiftUI
import SwiftData

@main
struct AgileFitnessTrainerApp: App {

    static let container: ModelContainer = {
        let schema = Schema([
            UserProfile.self,
            WorkoutPlan.self,
            PlannedWorkoutDay.self,
            PlannedExercise.self,
            Exercise.self,
            WeightEntry.self,
            WorkoutSession.self,
            SessionExercise.self,
            CompletedSet.self,
            HealthMetricsSnapshot.self
        ])
        let config = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
        return try! ModelContainer(
            for: schema,
            configurations: config
        )
    }()

    @StateObject private var healthKitService = HealthKitService()

    var body: some Scene {
        WindowGroup {
            RootView()
                .modelContainer(Self.container)
                .environmentObject(healthKitService)
        }
    }
}

struct RootView: View {
    @Query private var profiles: [UserProfile]

    var body: some View {
        if profiles.isEmpty {
            OnboardingView()
        } else {
            DashboardView()
        }
    }
}
